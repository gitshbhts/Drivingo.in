  <!-- start footer -->
        <div class="page-footer">
            <div class="page-footer-inner"> 2017 &copy; Designed by 
            <a href='' target="_blank">Kunja Techno</a>
            </div>
            <div class="scroll-to-top">
                <i class="icon-arrow-up"></i>
            </div>
        </div>
        <!-- end footer -->
    </div>
    <script src="<?php echo base_url();?>public/b/js/jquery.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>public/b/js/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>public/b/js/jquery.blockui.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>public/b/js/bootstrap-switch/js/bootstrap-switch.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>public/b/js/counterup/jquery.waypoints.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>public/b/js/counterup/jquery.counterup.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>public/b/js/jquery.slimscroll.js"></script>
    <script src="<?php echo base_url();?>public/b/js/app.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>public/b/js/layout.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>public/b/js/chart-js/Chart.bundle.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>public/b/js/chart-js/utils.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>public/b/js/chart-js/home-data.js" type="text/javascript"></script>

<! -------------------datepicke------->
     <script src="<?php echo base_url();?>public/b/js/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>public/b/js/bootstrap-switch/js/bootstrap-switch.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>public/b/js/bootstrap-wizard/jquery.bootstrap.wizard.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>public/b/js/bootstrap-datetimepicker/js/bootstrap-datetimepicker.js" type="text/javascript" charset="UTF-8"></script>
    <script src="<?php echo base_url();?>public/b/js/bootstrap-datetimepicker/js/bootstrap-datetimepicker-init.js" type="text/javascript" charset="UTF-8"></script>
    <script src="<?php echo base_url();?>public/b/js/bootstrap-timepicker/js/bootstrap-timepicker.min.js" type="text/javascript" charset="UTF-8"></script>
    <script src="<?php echo base_url();?>public/b/js/bootstrap-timepicker/js/bootstrap-timepicker-init.js" type="text/javascript" charset="UTF-8"></script>


     <script src="<?php echo base_url();?>public/b/js/dropzone/dropzone.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>public/b/js/dropzone/dropzone-call.js" type="text/javascript"></script>
    

    <!------------table plugin---------->
    <script src="<?php echo base_url();?>public/b/js/datatables/datatables.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>public/b/js/datatables/plugins/bootstrap/datatables.bootstrap.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>public/b/js/table_data.js" type="text/javascript"></script>
    
  </body>

<!-- Mirrored from www.radixtouch.in/hospital/source/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 26 Sep 2017 06:24:16 GMT -->
</html>