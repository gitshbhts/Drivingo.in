<?php $this->load->view('b/include/header');?>	
            <?php echo $this->load->view($main_content);?>        
<?php $this->load->view('b/include/footer');?>	