 <div class="row" style="background-color:white;">
 <div class="" >
			       <h3 class="w3ls-title" style="margin:20px;">About</h3>
				 
		    <div class="col-md-12" >
		  
			<div class="col-md-4">    <div align="center"><image src="<?php echo base_url();?>public/a/images/male.png" style="width:50%;"></div>                                                 <p  style="text-align:center;color:#2ad2c9;font-size:20px;" ><b >Director name</b> </p><p style="text-align:center;font:18px;"><b>Kundan  Kumar</b></p> </div>
			
<div class="col-md-4"><div align="center"><image src="<?php echo base_url();?>public/a/images/women-icon.png" style="width:50%;"></div>
    	<p style="text-align:center;color:#2ad2c9;font-size:20px;"><b>Executives</b></p><p style="text-align:center;font:18px;" ><b>Shreya Jain</b></p> 
			</div>
			<div class="col-md-4">
			    <div align="center"><image src="<?php echo base_url();?>public/a/images/male.png" style="width:50%;"></div><p style="text-align:center;color:#2ad2c9;font-size:20px;"><b>Executive</b></p> <p style="text-align:center;font:18px;" ><b>Shobhit Shrivastav</b></p></div>
			
		</div>
		</div>
		</div>
		<div class="clearfix"></div>
		
			</div>