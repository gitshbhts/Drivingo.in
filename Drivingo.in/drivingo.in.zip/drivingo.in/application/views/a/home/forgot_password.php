<div class="container">
	
<div class="col-sm-12">
<br>
<h2 align="center" style="padding-top:10px; padding-bottom:10px;color:white; "><b><u> Forgot Password</u></b></h2>
<div class="row" style="padding-top:50px; ">

<div class="w3agile contact">
			     <div class="contact-form">
								<form action="<?php echo base_url();?>index.php/home/forgot_password" method="post">
									
									<input type="text" name="user_phone" placeholder="Please Enter Your Number"  required=""/>
									
								     <input type="submit" value="Submit" style="background-color:#29d1c8; border-radius:5px;">		
								</form> 
				</div> 
							
			</div>




 
 <br><br>
 
  
</div>

</div>