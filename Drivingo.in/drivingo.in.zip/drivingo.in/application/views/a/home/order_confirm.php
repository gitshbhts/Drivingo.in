<div class="w3agile contact" >
			     <div class="" style="">
			         <?php echo $this->session->flashdata('msg')?>
							<div class="row" align="center">
								<button   value="White Button" onclick="window.location.href='<?php echo base_url();?>index.php/home'"" style="background-color:#2ad2c9;border:2px solid #2ad2c9;">Home</button>
								<button   value="White Button" onclick="window.location.href='<?php echo base_url();?>index.php/home/purchase_history'"" style="background-color:#2ad2c9;border:2px solid #2ad2c9;">Purchase History</button>
						</div>	
							</div> 
						
			</div>