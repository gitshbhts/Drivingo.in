<div class="w3agile contact">
			     <div class="contact-form">
			         <div align="center">
			             <h2 style="text-align:center;">DRIVINGO</h2>
			             <p style="text-align:center;"><i class="fa fa-map-marker" aria-hidden="true"></i>&nbsp &nbsp &nbsp Kunja Techno Pvt Ltd. <br>
2nd Floor, Academic Block <br>
SMVDU , Katra <br>
Jammu & Kashmir <br>
182320.
</p>
<p style="text-align:center;">
CIN :U74999JK2017PTC009990 <br>
<i class="fa fa-phone" aria-hidden="true" style="margin-left:-80px;"></i>&nbsp &nbsp &nbsp   8368466342 <br>
<i class="fa fa-envelope" aria-hidden="true"></i>&nbsp &nbsp &nbsp contact@drivingo.in  </p>
			         </div>
								<form action="#" method="post">
									<p>Your Name </p>
									<input type="text" name="Your Name"  required=""/>
									<p>Your Email </p>
									<input type="text" name="Your Email"  required=""/>
									<p>Your Message</p>
									<textarea placeholder="" required=""></textarea>
								     <input type="submit" value="Submit">		
								</form> 
							</div> 
							<div class="map">
							  	<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d107421.55889073142!2d74.78992434948105!3d32.71465473368207!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x391e84bf169d3525%3A0xf233488eeb8fd8d!2sJammu!5e0!3m2!1sen!2sin!4v1513254526314" frameborder="0" style="border:0" allowfullscreen></iframe>
							</div>
			</div>