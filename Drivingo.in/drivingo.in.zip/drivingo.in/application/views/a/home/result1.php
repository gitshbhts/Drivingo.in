<div class="container">
<br>


<div class="col-md-12"> <p style="text-align:center;">

</div>


<div class="w3agile experts">
  <div class="row" style="background-color:#29d1c8 "><h4 align="center" style="padding-top:10px; padding-bottom:10px; "><b> 10 Practical Classes (1 hour/day)</b></h4>

</div>
<div align="center"><img src="<?php echo base_url();?>public/a/images/SAD.png" style="width:25%;"></div>

<h4 style="text-align:center;"><?php echo $data;?></h4>
<div align="center"><button  style="background-color:#2ad2c9; " class="transparent_btn"  value="White Button" onclick="window.location.href='<?php echo base_url();?>index.php#search'"">Back</button></div>

  </div>
</div>