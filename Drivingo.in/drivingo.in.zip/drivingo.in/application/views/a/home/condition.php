<div class="container">
	
<div class="col-sm-12" style="background-color:white">
<br>
<h2 align="center" style="padding-top:10px; padding-bottom:10px;color:black;; "><b><u>Terms and Conditions.</u></b></h2>
<div class="row" style="padding-top:50px;background-color:white; ">
    <h2></h2>
    <?php foreach($terms as $data){?>
<p style="padding:20px;"><?php echo $data['terms_condition'];?>
</p>
<?php } ?>
 <br><br>
 <div class="row"><h4 style="padding-bottom:10px; "><h3> <p align="center"><b></b></h4></div>
  
</div>

</div>
</div>
