
<?php $this->load->view('a/include/header1');?>	
            <?php echo $this->load->view($main_content);?>        
<?php $this->load->view('a/include/footer');?>	
