
<?php $this->load->view('a/include/header');?>	
            <?php echo $this->load->view($main_content);?>        
<?php $this->load->view('a/include/footer');?>	
