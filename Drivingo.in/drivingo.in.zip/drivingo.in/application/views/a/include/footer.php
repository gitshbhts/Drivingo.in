	 <div class="w3agile footer">
			<div class="col-md-3 w3agile_footer_grid">
				
				<h3 class="logo" style=""><a href="http://www.drivingo.in/" style="text-align:center;">D<span>r</span>I<span>v</span>I<span>n</span><span>G</span>o<span></span></a></h3>
			             <p style="color:white;"><i class="fa fa-map-marker" aria-hidden="true"></i>&nbsp Kunja Techno Pvt Ltd. <br>
2nd Floor, Academic Block <br>
SMVDU , Katra <br>
Jammu & Kashmir <br>
182320.
</p>
<p style="color:white;">
CIN :U74999JK2017PTC009990 <br>
<i class="fa fa-phone" aria-hidden="true" style=""></i>:   8368466342 <br>
<i class="fa fa-envelope" aria-hidden="true"></i>: contact@drivingo.in  </p>
			</div>
		
			<div class="col-md-4 w3agile_footer_grid">
				<h3>Testimonials</h3>
				<ul class="w3agile_footer_grid_list">
					<li style="color:white;">I was fed up with my last driving trainer. Finally, I could get some true reviews about a driving class nearby my locality. Now I can say U am a proficient driver with the help of Drivingo.in.
						<span><b style="color:white;">Shraddha Rastogi</b> </span></li>
					<li style="color:white;">I needed help with the RTO services to make my driving license. Drivingo.in took care of the hectic process for me. I just had to attend the round of test and a verification. Thankyou Drivingo. You are changing lives.<span style="color:white;"><b>Richa Sachdeva</b> </span></li>
				</ul>
			</div>
    	<div class="col-md-3 w3agile_footer_grid">
    	    <h4 > <b style="color:white:margin:10px;">SMS PARTNER BY:</b></h4>
		<a href="https://msg91.com/startups/?utm_source=startup-banner"><img src="https://msg91.com/images/startups/msg91Badge.png" width="120" height="90" title="MSG91 - SMS for Startups" alt="Bulk SMS - MSG91" style="margin-top:20px;margin-bottom:20px;margin-right:20px;" ></a>
		 <h4 > <b style="color:white:margin:10px;">SUPPORTED BY:</b></h4>
		<img src="<?php echo base_url();?>public/a/images/logo.jpg" width="200" height="90" style="margin-top:20px;margin-bottom:10px;margin-right:10px;">
			<br>	<br>
			
		<br>
			<div class="row" style=""></div>
			<img><img>
			</div>
			<div class="clearfix"> </div>
		</div>

		<div class="w3agile agileinfo_copy_right">
			<div class="agileinfo_copy_right_left">
				<p>© 2017 Kunja Techno. All rights reserved | Designed by <a>Kunja Techno</a></p>
			</div>
			<div class="agileinfo_copy_right_right">
				<ul class="social">
					<li><a class="social-linkedin" target="_blank" href="https://www.facebook.com/drivingo">
						<i></i>
						<div class="tooltip"><span>Facebook</span></div>
						</a></li>
					<li><a class="social-twitter" target="_blank"  href="https://www.twitter.com/drivingoindia">
						<i></i>
						<div class="tooltip"><span>Twitter</span></div>
						</a></li>
				
				</ul>
			</div>
			<div class="clearfix"> </div>
	</div>
<script src="js/jquery.magnific-popup.js" type="text/javascript"></script>
	    <script>
			$(document).ready(function() {
				$('.popup-top-anim').magnificPopup({
					type: 'inline',
					fixedContentPos: false,
					fixedBgPos: true,
					overflowY: 'auto',
					closeBtnInside: true,
					preloader: false,
					midClick: true,
					removalDelay: 300,
					mainClass: 'my-mfp-zoom-in'
				});																							
			}); 
		</script>
<!--//pop-up-box -->
 <script src="js/bootstrap.min.js"></script>
<script src="js/jquery.nicescroll.js"></script>
<script src="js/scripts.js"></script>